/**
 * Will Generator Application JavaScript
 * 
 * Handles form interactivity, validation, autosave, and PDF generation
 */

(function() {
    'use strict';

    // Configuration
    const CONFIG = {
        AUTOSAVE_DELAY: 2000,
        API_BASE: '/api',
        STORAGE_KEY: 'will_generator_draft'
    };

    // State
    let autosaveTimeout = null;
    let formData = {};
    let beneficiaries = [];
    let children = [];
    let dependants = [];
    let executors = [];
    let backupExecutors = [];
    let businessInterests = [];
    let exclusions = [];

    // DOM Elements
    const form = document.getElementById('will-form');
    const errorSummary = document.getElementById('error-summary');
    const errorList = document.getElementById('error-list');
    const loadingOverlay = document.getElementById('loading-overlay');
    const successModal = document.getElementById('success-modal');
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.getElementById('nav-list');

    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
        init();
    });

    function init() {
        loadFromStorage();
        setupEventListeners();
        setupConditionalFields();
        setupNavigation();
        updateSummary();
    }

    // Event Listeners
    function setupEventListeners() {
        // Form input changes (autosave)
        form.addEventListener('input', handleInput);
        form.addEventListener('change', handleChange);

        // Form submission
        form.addEventListener('submit', handleSubmit);

        // Add buttons
        document.querySelectorAll('.btn-add').forEach(btn => {
            btn.addEventListener('click', handleAddClick);
        });

        // Clear button
        document.getElementById('btn-clear').addEventListener('click', handleClear);

        // Download JSON button
        document.getElementById('btn-download-json').addEventListener('click', handleDownloadJSON);

        // Modal buttons
        document.getElementById('btn-modal-close').addEventListener('click', closeModal);
        document.getElementById('btn-modal-download').addEventListener('click', handleModalDownload);

        // Navigation toggle (mobile)
        if (navToggle) {
            navToggle.addEventListener('click', toggleNavigation);
        }

        // Relationship status change
        const relationshipSelect = document.getElementById('will_maker.relationship_status');
        if (relationshipSelect) {
            relationshipSelect.addEventListener('change', handleRelationshipChange);
        }

        // Has children toggle
        const hasChildrenCheckbox = document.getElementById('has_children');
        if (hasChildrenCheckbox) {
            hasChildrenCheckbox.addEventListener('change', handleHasChildrenChange);
        }

        // Has dependants toggle
        const hasDependantsCheckbox = document.getElementById('has_other_dependants');
        if (hasDependantsCheckbox) {
            hasDependantsCheckbox.addEventListener('change', handleHasDependantsChange);
        }

        // Executor mode change
        const executorModeSelect = document.getElementById('executors.mode');
        if (executorModeSelect) {
            executorModeSelect.addEventListener('change', handleExecutorModeChange);
        }

        // Backup executor mode change
        const backupExecutorModeSelect = document.getElementById('executors.backup.mode');
        if (backupExecutorModeSelect) {
            backupExecutorModeSelect.addEventListener('change', handleBackupExecutorModeChange);
        }

        // Appoint guardian toggle
        const appointGuardianCheckbox = document.getElementById('appoint_guardian');
        if (appointGuardianCheckbox) {
            appointGuardianCheckbox.addEventListener('change', handleAppointGuardianChange);
        }

        // Has backup guardian toggle
        const hasBackupGuardianCheckbox = document.getElementById('has_backup_guardian');
        if (hasBackupGuardianCheckbox) {
            hasBackupGuardianCheckbox.addEventListener('change', handleHasBackupGuardianChange);
        }

        // Substitution rule change
        const substitutionRuleSelect = document.getElementById('substitution.rule');
        if (substitutionRuleSelect) {
            substitutionRuleSelect.addEventListener('change', handleSubstitutionRuleChange);
        }

        // Minor trusts toggle
        const minorTrustsCheckbox = document.getElementById('minor_trusts_enabled');
        if (minorTrustsCheckbox) {
            minorTrustsCheckbox.addEventListener('change', handleMinorTrustsChange);
        }

        // Trustee mode change
        const trusteeModeSelect = document.getElementById('minor_trusts.trustee_mode');
        if (trusteeModeSelect) {
            trusteeModeSelect.addEventListener('change', handleTrusteeModeChange);
        }

        // Toggle sections
        setupToggleListeners();

        // Pets care mode change
        const petsCareModeSelect = document.getElementById('pets.care_person_mode');
        if (petsCareModeSelect) {
            petsCareModeSelect.addEventListener('change', handlePetsCareModeChange);
        }
    }

    function setupToggleListeners() {
        const toggles = [
            { id: 'toggle_funeral', fields: 'funeral-fields' },
            { id: 'toggle_digital_assets', fields: 'digital-assets-fields' },
            { id: 'toggle_pets', fields: 'pets-fields' },
            { id: 'toggle_business', fields: 'business-fields' },
            { id: 'toggle_exclusion', fields: 'exclusion-fields' },
            { id: 'toggle_life_sustaining', fields: 'life-sustaining-fields' }
        ];

        toggles.forEach(toggle => {
            const checkbox = document.getElementById(toggle.id);
            const fields = document.getElementById(toggle.fields);
            if (checkbox && fields) {
                checkbox.addEventListener('change', function() {
                    fields.classList.toggle('hidden', !this.checked);
                });
            }
        });
    }

    // Conditional Field Handlers
    function setupConditionalFields() {
        // Trigger initial state
        handleRelationshipChange({ target: document.getElementById('will_maker.relationship_status') });
        handleHasChildrenChange({ target: document.getElementById('has_children') });
        handleHasDependantsChange({ target: document.getElementById('has_other_dependants') });
        handleExecutorModeChange({ target: document.getElementById('executors.mode') });
        handleBackupExecutorModeChange({ target: document.getElementById('executors.backup.mode') });
        handleAppointGuardianChange({ target: document.getElementById('appoint_guardian') });
        handleHasBackupGuardianChange({ target: document.getElementById('has_backup_guardian') });
        handleSubstitutionRuleChange({ target: document.getElementById('substitution.rule') });
        handleMinorTrustsChange({ target: document.getElementById('minor_trusts_enabled') });
        handleTrusteeModeChange({ target: document.getElementById('minor_trusts.trustee_mode') });
        handlePetsCareModeChange({ target: document.getElementById('pets.care_person_mode') });
    }

    function handleRelationshipChange(e) {
        const value = e.target ? e.target.value : '';
        const partnerFields = document.getElementById('partner-fields');
        const separationFields = document.getElementById('separation-fields');

        if (partnerFields) {
            partnerFields.classList.toggle('hidden', value !== 'married' && value !== 'de_facto');
        }
        if (separationFields) {
            separationFields.classList.toggle('hidden', value !== 'separated');
        }
    }

    function handleHasChildrenChange(e) {
        const container = document.getElementById('children-container');
        if (container) {
            container.classList.toggle('hidden', !e.target.checked);
        }
        updateGuardianshipVisibility();
    }

    function handleHasDependantsChange(e) {
        const container = document.getElementById('dependants-container');
        if (container) {
            container.classList.toggle('hidden', !e.target.checked);
        }
    }

    function handleExecutorModeChange(e) {
        const value = e.target ? e.target.value : '';
        const container = document.getElementById('executors-container');
        if (container) {
            const show = value === 'one' || value === 'two_joint' || value === 'two_joint_and_several';
            container.classList.toggle('hidden', !show);
            if (show && executors.length === 0) {
                const count = value === 'one' ? 1 : 2;
                for (let i = 0; i < count; i++) {
                    addExecutor();
                }
            }
        }
    }

    function handleBackupExecutorModeChange(e) {
        const value = e.target ? e.target.value : '';
        const container = document.getElementById('backup-executors-container');
        if (container) {
            const show = value === 'one' || value === 'two_joint' || value === 'two_joint_and_several';
            container.classList.toggle('hidden', !show);
            if (show && backupExecutors.length === 0) {
                const count = value === 'one' ? 1 : 2;
                for (let i = 0; i < count; i++) {
                    addBackupExecutor();
                }
            }
        }
    }

    function updateGuardianshipVisibility() {
        const hasChildren = document.getElementById('has_children')?.checked;
        const infoBox = document.getElementById('guardianship-info');
        const fields = document.getElementById('guardianship-fields');

        // Check if any child is marked as expected to be minor
        const hasMinorChildren = children.some(c => c.is_expected_to_be_minor);

        if (infoBox) {
            infoBox.classList.toggle('hidden', hasMinorChildren);
        }
        if (fields) {
            fields.classList.toggle('hidden', !hasMinorChildren);
        }
    }

    function handleAppointGuardianChange(e) {
        const details = document.getElementById('guardian-details');
        if (details) {
            details.classList.toggle('hidden', !e.target.checked);
        }
    }

    function handleHasBackupGuardianChange(e) {
        const details = document.getElementById('backup-guardian-details');
        if (details) {
            details.classList.toggle('hidden', !e.target.checked);
        }
    }

    function handleSubstitutionRuleChange(e) {
        const value = e.target ? e.target.value : '';
        const field = document.getElementById('alternate-beneficiary-field');
        if (field) {
            field.classList.toggle('hidden', value !== 'to_alternate_beneficiary');
            if (value === 'to_alternate_beneficiary') {
                updateAlternateBeneficiaryOptions();
            }
        }
    }

    function handleMinorTrustsChange(e) {
        const fields = document.getElementById('minor-trusts-fields');
        if (fields) {
            fields.classList.toggle('hidden', !e.target.checked);
        }
    }

    function handleTrusteeModeChange(e) {
        const value = e.target ? e.target.value : '';
        const fields = document.getElementById('named-trustee-fields');
        if (fields) {
            fields.classList.toggle('hidden', value !== 'named_trustee');
        }
    }

    function handlePetsCareModeChange(e) {
        const value = e.target ? e.target.value : '';
        const beneficiaryField = document.getElementById('pets-beneficiary-field');
        const carerField = document.getElementById('pets-carer-field');

        if (beneficiaryField) {
            beneficiaryField.classList.toggle('hidden', value !== 'select_beneficiary');
        }
        if (carerField) {
            carerField.classList.toggle('hidden', value !== 'new_person');
        }

        if (value === 'select_beneficiary') {
            updatePetsBeneficiaryOptions();
        }
    }

    // Dynamic List Handlers
    function handleAddClick(e) {
        const type = e.currentTarget.dataset.add;
        switch (type) {
            case 'child':
                addChild();
                break;
            case 'dependant':
                addDependant();
                break;
            case 'executor':
                addExecutor();
                break;
            case 'backup_executor':
                addBackupExecutor();
                break;
            case 'beneficiary':
                addBeneficiary();
                break;
            case 'business_interest':
                addBusinessInterest();
                break;
            case 'exclusion':
                addExclusion();
                break;
        }
    }

    function addChild() {
        const index = children.length;
        const child = {
            id: `child_${index}`,
            full_name: '',
            dob: '',
            relationship_type: 'biological',
            is_expected_to_be_minor_at_death: false,
            special_needs: false
        };
        children.push(child);
        renderChild(child, index);
        updateGuardianshipVisibility();
    }

    function renderChild(child, index) {
        const container = document.getElementById('children-list');
        if (!container) return;

        const div = document.createElement('div');
        div.className = 'dynamic-item';
        div.dataset.index = index;
        div.innerHTML = `
            <div class="dynamic-item-header">
                <span class="dynamic-item-title">Child ${index + 1}</span>
                <button type="button" class="btn btn-remove" onclick="removeChild(${index})">Remove</button>
            </div>
            <div class="form-row">
                <div class="form-group form-group-large">
                    <label>Full Name</label>
                    <input type="text" name="children[${index}].full_name" value="${child.full_name}" 
                           onchange="updateChild(${index}, 'full_name', this.value)">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Date of Birth</label>
                    <input type="date" name="children[${index}].dob" value="${child.dob}"
                           onchange="updateChild(${index}, 'dob', this.value)">
                </div>
                <div class="form-group">
                    <label>Relationship</label>
                    <select name="children[${index}].relationship_type" 
                            onchange="updateChild(${index}, 'relationship_type', this.value)">
                        <option value="biological" ${child.relationship_type === 'biological' ? 'selected' : ''}>Biological</option>
                        <option value="adopted" ${child.relationship_type === 'adopted' ? 'selected' : ''}>Adopted</option>
                        <option value="stepchild" ${child.relationship_type === 'stepchild' ? 'selected' : ''}>Stepchild</option>
                        <option value="dependent_other" ${child.relationship_type === 'dependent_other' ? 'selected' : ''}>Other Dependent</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" ${child.is_expected_to_be_minor_at_death ? 'checked' : ''}
                               onchange="updateChild(${index}, 'is_expected_to_be_minor_at_death', this.checked)">
                        <span class="checkbox-text">Expected to be a minor at time of death</span>
                    </label>
                </div>
            </div>
        `;
        container.appendChild(div);
    }

    window.removeChild = function(index) {
        children.splice(index, 1);
        refreshChildrenList();
        updateGuardianshipVisibility();
    };

    window.updateChild = function(index, field, value) {
        children[index][field] = value;
        scheduleAutosave();
    };

    function refreshChildrenList() {
        const container = document.getElementById('children-list');
        if (!container) return;
        container.innerHTML = '';
        children.forEach((child, index) => {
            child.id = `child_${index}`;
            renderChild(child, index);
        });
    }

    function addDependant() {
        const index = dependants.length;
        const dependant = { id: `dependant_${index}`, full_name: '', relationship_category: '' };
        dependants.push(dependant);
        renderDependant(dependant, index);
    }

    function renderDependant(dependant, index) {
        const container = document.getElementById('dependants-list');
        if (!container) return;

        const div = document.createElement('div');
        div.className = 'dynamic-item';
        div.dataset.index = index;
        div.innerHTML = `
            <div class="dynamic-item-header">
                <span class="dynamic-item-title">Dependant ${index + 1}</span>
                <button type="button" class="btn btn-remove" onclick="removeDependant(${index})">Remove</button>
            </div>
            <div class="form-row">
                <div class="form-group form-group-large">
                    <label>Full Name</label>
                    <input type="text" value="${dependant.full_name}"
                           onchange="updateDependant(${index}, 'full_name', this.value)">
                </div>
                <div class="form-group">
                    <label>Relationship</label>
                    <input type="text" value="${dependant.relationship_category}" maxlength="60"
                           onchange="updateDependant(${index}, 'relationship_category', this.value)">
                </div>
            </div>
        `;
        container.appendChild(div);
    }

    window.removeDependant = function(index) {
        dependants.splice(index, 1);
        refreshDependantsList();
    };

    window.updateDependant = function(index, field, value) {
        dependants[index][field] = value;
        scheduleAutosave();
    };

    function refreshDependantsList() {
        const container = document.getElementById('dependants-list');
        if (!container) return;
        container.innerHTML = '';
        dependants.forEach((dep, index) => {
            dep.id = `dependant_${index}`;
            renderDependant(dep, index);
        });
    }

    function addExecutor() {
        const index = executors.length;
        const executor = { id: `executor_${index}`, full_name: '', relationship: '', address: {} };
        executors.push(executor);
        renderExecutor(executor, index);
    }

    function renderExecutor(executor, index) {
        const container = document.getElementById('executors-list');
        if (!container) return;

        const div = document.createElement('div');
        div.className = 'dynamic-item';
        div.dataset.index = index;
        div.innerHTML = `
            <div class="dynamic-item-header">
                <span class="dynamic-item-title">Executor ${index + 1}</span>
                <button type="button" class="btn btn-remove" onclick="removeExecutor(${index})">Remove</button>
            </div>
            <div class="form-row">
                <div class="form-group form-group-large">
                    <label>Full Name</label>
                    <input type="text" value="${executor.full_name}"
                           onchange="updateExecutor(${index}, 'full_name', this.value)">
                </div>
                <div class="form-group">
                    <label>Relationship</label>
                    <input type="text" value="${executor.relationship}" maxlength="60"
                           onchange="updateExecutor(${index}, 'relationship', this.value)">
                </div>
            </div>
            <div class="form-group">
                <label>Street Address</label>
                <input type="text" value="${executor.address.street || ''}"
                       onchange="updateExecutorAddress(${index}, 'street', this.value)">
            </div>
            <div class="form-row address-row">
                <div class="form-group">
                    <label>Suburb</label>
                    <input type="text" value="${executor.address.suburb || ''}"
                           onchange="updateExecutorAddress(${index}, 'suburb', this.value)">
                </div>
                <div class="form-group form-group-small">
                    <label>State</label>
                    <input type="text" value="${executor.address.state || 'QLD'}"
                           onchange="updateExecutorAddress(${index}, 'state', this.value)">
                </div>
                <div class="form-group form-group-small">
                    <label>Postcode</label>
                    <input type="text" value="${executor.address.postcode || ''}" maxlength="4"
                           onchange="updateExecutorAddress(${index}, 'postcode', this.value)">
                </div>
            </div>
        `;
        container.appendChild(div);
    }

    window.removeExecutor = function(index) {
        executors.splice(index, 1);
        refreshExecutorsList();
    };

    window.updateExecutor = function(index, field, value) {
        executors[index][field] = value;
        scheduleAutosave();
    };

    window.updateExecutorAddress = function(index, field, value) {
        if (!executors[index].address) executors[index].address = {};
        executors[index].address[field] = value;
        scheduleAutosave();
    };

    function refreshExecutorsList() {
        const container = document.getElementById('executors-list');
        if (!container) return;
        container.innerHTML = '';
        executors.forEach((exec, index) => {
            exec.id = `executor_${index}`;
            renderExecutor(exec, index);
        });
    }

    function addBackupExecutor() {
        const index = backupExecutors.length;
        const executor = { id: `backup_executor_${index}`, full_name: '', relationship: '', address: {} };
        backupExecutors.push(executor);
        renderBackupExecutor(executor, index);
    }

    function renderBackupExecutor(executor, index) {
        const container = document.getElementById('backup-executors-list');
        if (!container) return;

        const div = document.createElement('div');
        div.className = 'dynamic-item';
        div.dataset.index = index;
        div.innerHTML = `
            <div class="dynamic-item-header">
                <span class="dynamic-item-title">Backup Executor ${index + 1}</span>
                <button type="button" class="btn btn-remove" onclick="removeBackupExecutor(${index})">Remove</button>
            </div>
            <div class="form-row">
                <div class="form-group form-group-large">
                    <label>Full Name</label>
                    <input type="text" value="${executor.full_name}"
                           onchange="updateBackupExecutor(${index}, 'full_name', this.value)">
                </div>
                <div class="form-group">
                    <label>Relationship</label>
                    <input type="text" value="${executor.relationship}" maxlength="60"
                           onchange="updateBackupExecutor(${index}, 'relationship', this.value)">
                </div>
            </div>
            <div class="form-group">
                <label>Street Address</label>
                <input type="text" value="${executor.address.street || ''}"
                       onchange="updateBackupExecutorAddress(${index}, 'street', this.value)">
            </div>
            <div class="form-row address-row">
                <div class="form-group">
                    <label>Suburb</label>
                    <input type="text" value="${executor.address.suburb || ''}"
                           onchange="updateBackupExecutorAddress(${index}, 'suburb', this.value)">
                </div>
                <div class="form-group form-group-small">
                    <label>State</label>
                    <input type="text" value="${executor.address.state || 'QLD'}"
                           onchange="updateBackupExecutorAddress(${index}, 'state', this.value)">
                </div>
                <div class="form-group form-group-small">
                    <label>Postcode</label>
                    <input type="text" value="${executor.address.postcode || ''}" maxlength="4"
                           onchange="updateBackupExecutorAddress(${index}, 'postcode', this.value)">
                </div>
            </div>
        `;
        container.appendChild(div);
    }

    window.removeBackupExecutor = function(index) {
        backupExecutors.splice(index, 1);
        refreshBackupExecutorsList();
    };

    window.updateBackupExecutor = function(index, field, value) {
        backupExecutors[index][field] = value;
        scheduleAutosave();
    };

    window.updateBackupExecutorAddress = function(index, field, value) {
        if (!backupExecutors[index].address) backupExecutors[index].address = {};
        backupExecutors[index].address[field] = value;
        scheduleAutosave();
    };

    function refreshBackupExecutorsList() {
        const container = document.getElementById('backup-executors-list');
        if (!container) return;
        container.innerHTML = '';
        backupExecutors.forEach((exec, index) => {
            exec.id = `backup_executor_${index}`;
            renderBackupExecutor(exec, index);
        });
    }

    function addBeneficiary() {
        const index = beneficiaries.length;
        const beneficiary = {
            id: `beneficiary_${index}`,
            type: 'individual',
            full_name: '',
            relationship: '',
            address: {},
            gift_role: 'residue'
        };
        beneficiaries.push(beneficiary);
        renderBeneficiary(beneficiary, index);
        updateAlternateBeneficiaryOptions();
        updatePetsBeneficiaryOptions();
    }

    function renderBeneficiary(beneficiary, index) {
        const container = document.getElementById('beneficiaries-list');
        if (!container) return;

        const div = document.createElement('div');
        div.className = 'dynamic-item';
        div.dataset.index = index;
        div.innerHTML = `
            <div class="dynamic-item-header">
                <span class="dynamic-item-title">Beneficiary ${index + 1}</span>
                <button type="button" class="btn btn-remove" onclick="removeBeneficiary(${index})">Remove</button>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Type</label>
                    <select onchange="updateBeneficiary(${index}, 'type', this.value)">
                        <option value="individual" ${beneficiary.type === 'individual' ? 'selected' : ''}>Individual</option>
                        <option value="charity" ${beneficiary.type === 'charity' ? 'selected' : ''}>Charity</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Gift Type</label>
                    <select onchange="updateBeneficiary(${index}, 'gift_role', this.value); refreshBeneficiariesList();">
                        <option value="residue" ${beneficiary.gift_role === 'residue' ? 'selected' : ''}>Residue</option>
                        <option value="specific_cash" ${beneficiary.gift_role === 'specific_cash' ? 'selected' : ''}>Specific Cash</option>
                        <option value="specific_item" ${beneficiary.gift_role === 'specific_item' ? 'selected' : ''}>Specific Item</option>
                        <option value="percentage_only" ${beneficiary.gift_role === 'percentage_only' ? 'selected' : ''}>Percentage Only</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-group-large">
                    <label>Full Name</label>
                    <input type="text" value="${beneficiary.full_name}"
                           onchange="updateBeneficiary(${index}, 'full_name', this.value)">
                </div>
                ${beneficiary.type === 'individual' ? `
                <div class="form-group">
                    <label>Relationship</label>
                    <input type="text" value="${beneficiary.relationship}" maxlength="60"
                           onchange="updateBeneficiary(${index}, 'relationship', this.value)">
                </div>
                ` : `
                <div class="form-group">
                    <label>ABN (optional)</label>
                    <input type="text" value="${beneficiary.abn || ''}" maxlength="11"
                           onchange="updateBeneficiary(${index}, 'abn', this.value)">
                </div>
                `}
            </div>
            ${beneficiary.gift_role === 'specific_cash' ? `
            <div class="form-row">
                <div class="form-group">
                    <label>Cash Amount</label>
                    <input type="number" value="${beneficiary.cash_amount || ''}" min="0" step="100"
                           onchange="updateBeneficiary(${index}, 'cash_amount', parseFloat(this.value) || 0)">
                </div>
            </div>
            ` : ''}
            ${beneficiary.gift_role === 'specific_item' ? `
            <div class="form-row">
                <div class="form-group form-group-large">
                    <label>Item Description</label>
                    <input type="text" value="${beneficiary.item_description || ''}" maxlength="120"
                           onchange="updateBeneficiary(${index}, 'item_description', this.value)">
                </div>
            </div>
            ` : ''}
            ${beneficiary.gift_role === 'percentage_only' ? `
            <div class="form-row">
                <div class="form-group form-group-small">
                    <label>Percentage</label>
                    <input type="number" value="${beneficiary.percentage || ''}" min="0" max="100" step="0.01"
                           onchange="updateBeneficiary(${index}, 'percentage', parseFloat(this.value) || 0)">
                </div>
            </div>
            ` : ''}
            ${beneficiary.type === 'individual' ? `
            <div class="form-group">
                <label>Street Address</label>
                <input type="text" value="${beneficiary.address.street || ''}"
                       onchange="updateBeneficiaryAddress(${index}, 'street', this.value)">
            </div>
            <div class="form-row address-row">
                <div class="form-group">
                    <label>Suburb</label>
                    <input type="text" value="${beneficiary.address.suburb || ''}"
                           onchange="updateBeneficiaryAddress(${index}, 'suburb', this.value)">
                </div>
                <div class="form-group form-group-small">
                    <label>State</label>
                    <input type="text" value="${beneficiary.address.state || 'QLD'}"
                           onchange="updateBeneficiaryAddress(${index}, 'state', this.value)">
                </div>
                <div class="form-group form-group-small">
                    <label>Postcode</label>
                    <input type="text" value="${beneficiary.address.postcode || ''}" maxlength="4"
                           onchange="updateBeneficiaryAddress(${index}, 'postcode', this.value)">
                </div>
            </div>
            ` : ''}
        `;
        container.appendChild(div);
    }

    window.removeBeneficiary = function(index) {
        beneficiaries.splice(index, 1);
        refreshBeneficiariesList();
        updateAlternateBeneficiaryOptions();
        updatePetsBeneficiaryOptions();
    };

    window.updateBeneficiary = function(index, field, value) {
        beneficiaries[index][field] = value;
        scheduleAutosave();
    };

    window.updateBeneficiaryAddress = function(index, field, value) {
        if (!beneficiaries[index].address) beneficiaries[index].address = {};
        beneficiaries[index].address[field] = value;
        scheduleAutosave();
    };

    function refreshBeneficiariesList() {
        const container = document.getElementById('beneficiaries-list');
        if (!container) return;
        container.innerHTML = '';
        beneficiaries.forEach((ben, index) => {
            ben.id = `beneficiary_${index}`;
            renderBeneficiary(ben, index);
        });
    }

    function updateAlternateBeneficiaryOptions() {
        const select = document.getElementById('substitution.alternate_beneficiary_id');
        if (!select) return;

        const currentValue = select.value;
        select.innerHTML = '<option value="">Select a beneficiary...</option>';

        beneficiaries.forEach((ben, index) => {
            if (ben.full_name) {
                const option = document.createElement('option');
                option.value = ben.id;
                option.textContent = ben.full_name;
                select.appendChild(option);
            }
        });

        select.value = currentValue;
    }

    function updatePetsBeneficiaryOptions() {
        const select = document.getElementById('pets.care_beneficiary_id');
        if (!select) return;

        const currentValue = select.value;
        select.innerHTML = '<option value="">Select a beneficiary...</option>';

        beneficiaries.forEach((ben, index) => {
            if (ben.full_name && ben.type === 'individual') {
                const option = document.createElement('option');
                option.value = ben.id;
                option.textContent = ben.full_name;
                select.appendChild(option);
            }
        });

        select.value = currentValue;
    }

    function addBusinessInterest() {
        const index = businessInterests.length;
        const interest = {
            id: `business_${index}`,
            interest_type: 'sole_trader',
            entity_name: '',
            recipient_mode: 'select_beneficiary'
        };
        businessInterests.push(interest);
        renderBusinessInterest(interest, index);
    }

    function renderBusinessInterest(interest, index) {
        const container = document.getElementById('business-interests-list');
        if (!container) return;

        const div = document.createElement('div');
        div.className = 'dynamic-item';
        div.dataset.index = index;
        div.innerHTML = `
            <div class="dynamic-item-header">
                <span class="dynamic-item-title">Business Interest ${index + 1}</span>
                <button type="button" class="btn btn-remove" onclick="removeBusinessInterest(${index})">Remove</button>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Type</label>
                    <select onchange="updateBusinessInterest(${index}, 'interest_type', this.value)">
                        <option value="sole_trader" ${interest.interest_type === 'sole_trader' ? 'selected' : ''}>Sole Trader</option>
                        <option value="company_shareholding" ${interest.interest_type === 'company_shareholding' ? 'selected' : ''}>Company Shareholding</option>
                        <option value="partnership" ${interest.interest_type === 'partnership' ? 'selected' : ''}>Partnership</option>
                        <option value="trust_interest" ${interest.interest_type === 'trust_interest' ? 'selected' : ''}>Trust Interest</option>
                    </select>
                </div>
                <div class="form-group form-group-large">
                    <label>Entity Name</label>
                    <input type="text" value="${interest.entity_name}"
                           onchange="updateBusinessInterest(${index}, 'entity_name', this.value)">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group form-group-small">
                    <label>ACN (optional)</label>
                    <input type="text" value="${interest.acn || ''}" maxlength="9"
                           onchange="updateBusinessInterest(${index}, 'acn', this.value)">
                </div>
                <div class="form-group form-group-small">
                    <label>ABN (optional)</label>
                    <input type="text" value="${interest.abn || ''}" maxlength="11"
                           onchange="updateBusinessInterest(${index}, 'abn', this.value)">
                </div>
            </div>
            <div class="form-group">
                <label>Recipient</label>
                <select onchange="updateBusinessInterest(${index}, 'recipient_mode', this.value); refreshBusinessInterestsList();">
                    <option value="select_beneficiary" ${interest.recipient_mode === 'select_beneficiary' ? 'selected' : ''}>Select Beneficiary</option>
                    <option value="new_person" ${interest.recipient_mode === 'new_person' ? 'selected' : ''}>New Person</option>
                </select>
            </div>
            ${interest.recipient_mode === 'select_beneficiary' ? `
            <div class="form-group">
                <label>Select Beneficiary</label>
                <select onchange="updateBusinessInterest(${index}, 'recipient_id', this.value)">
                    <option value="">Select...</option>
                    ${beneficiaries.map(b => `<option value="${b.id}" ${interest.recipient_id === b.id ? 'selected' : ''}>${b.full_name}</option>`).join('')}
                </select>
            </div>
            ` : `
            <div class="form-row">
                <div class="form-group form-group-large">
                    <label>Recipient's Full Name</label>
                    <input type="text" value="${interest.recipient_name || ''}"
                           onchange="updateBusinessInterest(${index}, 'recipient_name', this.value)">
                </div>
            </div>
            <div class="form-group">
                <label>Street Address</label>
                <input type="text" value="${interest.recipient_address?.street || ''}"
                       onchange="updateBusinessInterestAddress(${index}, 'street', this.value)">
            </div>
            <div class="form-row address-row">
                <div class="form-group">
                    <label>Suburb</label>
                    <input type="text" value="${interest.recipient_address?.suburb || ''}"
                           onchange="updateBusinessInterestAddress(${index}, 'suburb', this.value)">
                </div>
                <div class="form-group form-group-small">
                    <label>State</label>
                    <input type="text" value="${interest.recipient_address?.state || 'QLD'}"
                           onchange="updateBusinessInterestAddress(${index}, 'state', this.value)">
                </div>
                <div class="form-group form-group-small">
                    <label>Postcode</label>
                    <input type="text" value="${interest.recipient_address?.postcode || ''}" maxlength="4"
                           onchange="updateBusinessInterestAddress(${index}, 'postcode', this.value)">
                </div>
            </div>
            `}
        `;
        container.appendChild(div);
    }

    window.removeBusinessInterest = function(index) {
        businessInterests.splice(index, 1);
        refreshBusinessInterestsList();
    };

    window.updateBusinessInterest = function(index, field, value) {
        businessInterests[index][field] = value;
        scheduleAutosave();
    };

    window.updateBusinessInterestAddress = function(index, field, value) {
        if (!businessInterests[index].recipient_address) businessInterests[index].recipient_address = {};
        businessInterests[index].recipient_address[field] = value;
        scheduleAutosave();
    };

    function refreshBusinessInterestsList() {
        const container = document.getElementById('business-interests-list');
        if (!container) return;
        container.innerHTML = '';
        businessInterests.forEach((interest, index) => {
            interest.id = `business_${index}`;
            renderBusinessInterest(interest, index);
        });
    }

    function addExclusion() {
        const index = exclusions.length;
        const exclusion = {
            id: `exclusion_${index}`,
            person_name: '',
            category: 'child',
            reasons: [],
            other_note: ''
        };
        exclusions.push(exclusion);
        renderExclusion(exclusion, index);
    }

    function renderExclusion(exclusion, index) {
        const container = document.getElementById('exclusions-list');
        if (!container) return;

        const div = document.createElement('div');
        div.className = 'dynamic-item';
        div.dataset.index = index;
        div.innerHTML = `
            <div class="dynamic-item-header">
                <span class="dynamic-item-title">Exclusion ${index + 1}</span>
                <button type="button" class="btn btn-remove" onclick="removeExclusion(${index})">Remove</button>
            </div>
            <div class="form-row">
                <div class="form-group form-group-large">
                    <label>Person's Name</label>
                    <input type="text" value="${exclusion.person_name}"
                           onchange="updateExclusion(${index}, 'person_name', this.value)">
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <select onchange="updateExclusion(${index}, 'category', this.value)">
                        <option value="former_partner" ${exclusion.category === 'former_partner' ? 'selected' : ''}>Former Partner</option>
                        <option value="child" ${exclusion.category === 'child' ? 'selected' : ''}>Child</option>
                        <option value="stepchild" ${exclusion.category === 'stepchild' ? 'selected' : ''}>Stepchild</option>
                        <option value="dependant_other" ${exclusion.category === 'dependant_other' ? 'selected' : ''}>Other Dependant</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>Reasons</label>
                <div class="checkbox-group">
                    <label class="checkbox-label">
                        <input type="checkbox" ${exclusion.reasons.includes('already_provided_for') ? 'checked' : ''}
                               onchange="toggleExclusionReason(${index}, 'already_provided_for', this.checked)">
                        <span class="checkbox-text">Already provided for</span>
                    </label>
                    <label class="checkbox-label">
                        <input type="checkbox" ${exclusion.reasons.includes('estrangement') ? 'checked' : ''}
                               onchange="toggleExclusionReason(${index}, 'estrangement', this.checked)">
                        <span class="checkbox-text">Estrangement</span>
                    </label>
                    <label class="checkbox-label">
                        <input type="checkbox" ${exclusion.reasons.includes('financial_independence') ? 'checked' : ''}
                               onchange="toggleExclusionReason(${index}, 'financial_independence', this.checked)">
                        <span class="checkbox-text">Financially independent</span>
                    </label>
                    <label class="checkbox-label">
                        <input type="checkbox" ${exclusion.reasons.includes('other_structured') ? 'checked' : ''}
                               onchange="toggleExclusionReason(${index}, 'other_structured', this.checked)">
                        <span class="checkbox-text">Other reason</span>
                    </label>
                </div>
            </div>
            ${exclusion.reasons.includes('other_structured') ? `
            <div class="form-group">
                <label>Other Reason Note</label>
                <textarea rows="2" maxlength="300" onchange="updateExclusion(${index}, 'other_note', this.value)">${exclusion.other_note}</textarea>
            </div>
            ` : ''}
        `;
        container.appendChild(div);
    }

    window.removeExclusion = function(index) {
        exclusions.splice(index, 1);
        refreshExclusionsList();
    };

    window.updateExclusion = function(index, field, value) {
        exclusions[index][field] = value;
        scheduleAutosave();
    };

    window.toggleExclusionReason = function(index, reason, checked) {
        const reasons = exclusions[index].reasons;
        if (checked) {
            if (!reasons.includes(reason)) reasons.push(reason);
        } else {
            const idx = reasons.indexOf(reason);
            if (idx > -1) reasons.splice(idx, 1);
        }
        refreshExclusionsList();
        scheduleAutosave();
    };

    function refreshExclusionsList() {
        const container = document.getElementById('exclusions-list');
        if (!container) return;
        container.innerHTML = '';
        exclusions.forEach((excl, index) => {
            excl.id = `exclusion_${index}`;
            renderExclusion(excl, index);
        });
    }

    // Form Handlers
    function handleInput(e) {
        scheduleAutosave();
        updateSummary();
    }

    function handleChange(e) {
        updateSummary();
    }

    function handleSubmit(e) {
        e.preventDefault();
        generateWill();
    }

    function handleClear() {
        if (confirm('Are you sure you want to clear all form data? This cannot be undone.')) {
            form.reset();
            children = [];
            dependants = [];
            executors = [];
            backupExecutors = [];
            beneficiaries = [];
            businessInterests = [];
            exclusions = [];
            refreshAllLists();
            localStorage.removeItem(CONFIG.STORAGE_KEY);
            updateSummary();
        }
    }

    function handleDownloadJSON() {
        const payload = buildPayload();
        const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `will_data_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    function handleModalDownload() {
        // This will be set when the PDF is generated
        closeModal();
    }

    // Autosave
    function scheduleAutosave() {
        if (autosaveTimeout) {
            clearTimeout(autosaveTimeout);
        }
        autosaveTimeout = setTimeout(saveToStorage, CONFIG.AUTOSAVE_DELAY);
    }

    function saveToStorage() {
        const payload = buildPayload();
        localStorage.setItem(CONFIG.STORAGE_KEY, JSON.stringify(payload));
    }

    function loadFromStorage() {
        const saved = localStorage.getItem(CONFIG.STORAGE_KEY);
        if (saved) {
            try {
                const payload = JSON.parse(saved);
                restorePayload(payload);
            } catch (e) {
                console.error('Failed to load saved data:', e);
            }
        }
    }

    function restorePayload(payload) {
        // Restore simple fields
        if (payload.will_maker) {
            Object.entries(payload.will_maker).forEach(([key, value]) => {
                if (key === 'address') {
                    Object.entries(value).forEach(([addrKey, addrValue]) => {
                        const el = document.getElementsByName(`will_maker.address.${addrKey}`)[0];
                        if (el) el.value = addrValue;
                    });
                } else {
                    const el = document.getElementsByName(`will_maker.${key}`)[0];
                    if (el) el.value = value;
                }
            });
        }

        // Trigger relationship change to show partner fields if needed
        const relationshipStatus = payload.will_maker?.relationship_status;
        if (relationshipStatus) {
            handleRelationshipChange({ target: { value: relationshipStatus } });
        }

        // Restore partner
        if (payload.partner) {
            Object.entries(payload.partner).forEach(([key, value]) => {
                if (key === 'address') {
                    Object.entries(value).forEach(([addrKey, addrValue]) => {
                        const el = document.getElementsByName(`partner.address.${addrKey}`)[0];
                        if (el) el.value = addrValue;
                    });
                } else {
                    const el = document.getElementsByName(`partner.${key}`)[0];
                    if (el) el.value = value;
                }
            });
        }

        // Restore children
        if (payload.has_children && payload.children) {
            document.getElementById('has_children').checked = true;
            children = payload.children;
            refreshChildrenList();
            handleHasChildrenChange({ target: { checked: true } });
        }

        // Restore dependants
        if (payload.dependants?.has_other_dependants && payload.dependants.other_dependants) {
            document.getElementById('has_other_dependants').checked = true;
            dependants = payload.dependants.other_dependants;
            refreshDependantsList();
            handleHasDependantsChange({ target: { checked: true } });
        }

        // Restore executors
        if (payload.executors) {
            const executorMode = document.getElementById('executors.mode');
            if (executorMode) executorMode.value = payload.executors.mode;
            
            if (payload.executors.primary) {
                executors = payload.executors.primary;
                refreshExecutorsList();
            }
            
            if (payload.executors.backup) {
                const backupMode = document.getElementById('executors.backup.mode');
                if (backupMode) backupMode.value = payload.executors.backup.mode;
                
                if (payload.executors.backup.list) {
                    backupExecutors = payload.executors.backup.list;
                    refreshBackupExecutorsList();
                }
            }
            
            handleExecutorModeChange({ target: { value: payload.executors.mode } });
            handleBackupExecutorModeChange({ target: { value: payload.executors.backup?.mode } });
        }

        // Restore beneficiaries
        if (payload.beneficiaries) {
            beneficiaries = payload.beneficiaries;
            refreshBeneficiariesList();
        }

        // Restore toggles
        if (payload.toggles) {
            if (payload.toggles.funeral?.enabled) {
                document.getElementById('toggle_funeral').checked = true;
                document.getElementById('funeral-fields').classList.remove('hidden');
            }
            if (payload.toggles.digital_assets?.enabled) {
                document.getElementById('toggle_digital_assets').checked = true;
                document.getElementById('digital-assets-fields').classList.remove('hidden');
            }
            if (payload.toggles.pets?.enabled) {
                document.getElementById('toggle_pets').checked = true;
                document.getElementById('pets-fields').classList.remove('hidden');
            }
            if (payload.toggles.business?.enabled) {
                document.getElementById('toggle_business').checked = true;
                document.getElementById('business-fields').classList.remove('hidden');
                if (payload.toggles.business.interests) {
                    businessInterests = payload.toggles.business.interests;
                    refreshBusinessInterestsList();
                }
            }
            if (payload.toggles.exclusion?.enabled) {
                document.getElementById('toggle_exclusion').checked = true;
                document.getElementById('exclusion-fields').classList.remove('hidden');
                if (payload.toggles.exclusion.exclusions) {
                    exclusions = payload.toggles.exclusion.exclusions;
                    refreshExclusionsList();
                }
            }
            if (payload.toggles.life_sustaining?.enabled) {
                document.getElementById('toggle_life_sustaining').checked = true;
                document.getElementById('life-sustaining-fields').classList.remove('hidden');
            }
        }

        updateGuardianshipVisibility();
    }

    function refreshAllLists() {
        refreshChildrenList();
        refreshDependantsList();
        refreshExecutorsList();
        refreshBackupExecutorsList();
        refreshBeneficiariesList();
        refreshBusinessInterestsList();
        refreshExclusionsList();
    }

    // Payload Builder
    function buildPayload() {
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // Handle checkbox groups
        const digitalAssetsCategories = Array.from(
            document.querySelectorAll('input[name="digital_assets.categories"]:checked')
        ).map(cb => cb.value);

        const lifeSustainingValues = Array.from(
            document.querySelectorAll('input[name="life_sustaining.values"]:checked')
        ).map(cb => cb.value);

        return {
            eligibility: {
                confirm_age_over_18: document.getElementsByName('eligibility.confirm_age_over_18')[0]?.checked || false,
                confirm_qld: document.getElementsByName('eligibility.confirm_qld')[0]?.checked || false,
                confirm_not_legal_advice: document.getElementsByName('eligibility.confirm_not_legal_advice')[0]?.checked || false
            },
            will_maker: {
                full_name: data['will_maker.full_name'] || '',
                dob: data['will_maker.dob'] || '',
                occupation: data['will_maker.occupation'] || '',
                address: {
                    street: data['will_maker.address.street'] || '',
                    suburb: data['will_maker.address.suburb'] || '',
                    state: data['will_maker.address.state'] || '',
                    postcode: data['will_maker.address.postcode'] || ''
                },
                email: data['will_maker.email'] || '',
                phone: data['will_maker.phone'] || '',
                relationship_status: data['will_maker.relationship_status'] || ''
            },
            partner: ['married', 'de_facto'].includes(data['will_maker.relationship_status']) ? {
                full_name: data['partner.full_name'] || '',
                dob: data['partner.dob'] || '',
                address: {
                    street: data['partner.address.street'] || '',
                    suburb: data['partner.address.suburb'] || '',
                    state: data['partner.address.state'] || '',
                    postcode: data['partner.address.postcode'] || ''
                },
                email: data['partner.email'] || '',
                phone: data['partner.phone'] || ''
            } : undefined,
            separation: data['will_maker.relationship_status'] === 'separated' ? {
                is_legally_separated: document.getElementsByName('separation.is_legally_separated')[0]?.checked || false,
                has_property_agreement: document.getElementsByName('separation.has_property_agreement')[0]?.checked || false
            } : undefined,
            has_children: document.getElementById('has_children')?.checked || false,
            children: children,
            dependants: {
                has_other_dependants: document.getElementById('has_other_dependants')?.checked || false,
                other_dependants: dependants
            },
            executors: {
                mode: data['executors.mode'] || '',
                primary: executors.length > 0 ? executors : undefined,
                backup: {
                    mode: data['executors.backup.mode'] || '',
                    list: backupExecutors.length > 0 ? backupExecutors : undefined
                }
            },
            guardianship: document.getElementById('appoint_guardian')?.checked ? {
                appoint_guardian: true,
                guardian: {
                    full_name: data['guardianship.guardian.full_name'] || '',
                    relationship: data['guardianship.guardian.relationship'] || '',
                    address: {
                        street: data['guardianship.guardian.address.street'] || '',
                        suburb: data['guardianship.guardian.address.suburb'] || '',
                        state: data['guardianship.guardian.address.state'] || '',
                        postcode: data['guardianship.guardian.address.postcode'] || ''
                    },
                    phone: data['guardianship.guardian.phone'] || ''
                },
                backup_guardian: document.getElementById('has_backup_guardian')?.checked ? {
                    full_name: data['guardianship.backup_guardian.full_name'] || '',
                    relationship: data['guardianship.backup_guardian.relationship'] || '',
                    address: {
                        street: data['guardianship.backup_guardian.address.street'] || '',
                        suburb: data['guardianship.backup_guardian.address.suburb'] || '',
                        state: data['guardianship.backup_guardian.address.state'] || '',
                        postcode: data['guardianship.backup_guardian.address.postcode'] || ''
                    }
                } : undefined
            } : undefined,
            distribution: {
                scheme: data['distribution.scheme'] || ''
            },
            beneficiaries: beneficiaries,
            survivorship: {
                days: parseInt(data['survivorship.days']) || 30
            },
            substitution: {
                rule: data['substitution.rule'] || '',
                alternate_beneficiary_id: data['substitution.alternate_beneficiary_id'] || undefined
            },
            minor_trusts: document.getElementById('minor_trusts_enabled')?.checked ? {
                enabled: true,
                vesting_age: parseInt(data['minor_trusts.vesting_age']) || 18,
                trustee_mode: data['minor_trusts.trustee_mode'] || '',
                trustee: data['minor_trusts.trustee_mode'] === 'named_trustee' ? {
                    full_name: data['minor_trusts.trustee.full_name'] || '',
                    address: {
                        street: data['minor_trusts.trustee.address.street'] || '',
                        suburb: data['minor_trusts.trustee.address.suburb'] || '',
                        state: data['minor_trusts.trustee.address.state'] || '',
                        postcode: data['minor_trusts.trustee.address.postcode'] || ''
                    }
                } : undefined
            } : undefined,
            toggles: {
                funeral: document.getElementById('toggle_funeral')?.checked ? {
                    enabled: true,
                    preference: data['funeral.preference'] || '',
                    notes: data['funeral.notes'] || ''
                } : undefined,
                digital_assets: document.getElementById('toggle_digital_assets')?.checked ? {
                    enabled: true,
                    authority: document.getElementById('digital_assets_authority')?.checked || false,
                    categories: digitalAssetsCategories,
                    instructions_location: data['digital_assets.instructions_location'] || ''
                } : undefined,
                pets: document.getElementById('toggle_pets')?.checked ? {
                    enabled: true,
                    count: parseInt(data['pets.count']) || 1,
                    summary: data['pets.summary'] || '',
                    care_person_mode: data['pets.care_person_mode'] || '',
                    care_beneficiary_id: data['pets.care_beneficiary_id'] || undefined,
                    carer: data['pets.care_person_mode'] === 'new_person' ? {
                        full_name: data['pets.carer.full_name'] || '',
                        address: {
                            street: data['pets.carer.address.street'] || '',
                            suburb: data['pets.carer.address.suburb'] || '',
                            state: data['pets.carer.address.state'] || '',
                            postcode: data['pets.carer.address.postcode'] || ''
                        }
                    } : undefined,
                    cash_gift: data['pets.cash_gift'] ? parseFloat(data['pets.cash_gift']) : undefined
                } : undefined,
                business: document.getElementById('toggle_business')?.checked ? {
                    enabled: true,
                    interests: businessInterests
                } : undefined,
                exclusion: document.getElementById('toggle_exclusion')?.checked ? {
                    enabled: true,
                    exclusions: exclusions
                } : undefined,
                life_sustaining: document.getElementById('toggle_life_sustaining')?.checked ? {
                    enabled: true,
                    template: data['life_sustaining.template'] || '',
                    values: lifeSustainingValues
                } : undefined
            },
            assets: {
                real_property: data['assets.real_property'] ? parseFloat(data['assets.real_property']) : undefined,
                bank: data['assets.bank'] ? parseFloat(data['assets.bank']) : undefined,
                superannuation: data['assets.superannuation'] ? parseFloat(data['assets.superannuation']) : undefined,
                investments: data['assets.investments'] ? parseFloat(data['assets.investments']) : undefined,
                vehicles: data['assets.vehicles'] ? parseFloat(data['assets.vehicles']) : undefined,
                business: data['assets.business'] ? parseFloat(data['assets.business']) : undefined,
                other: data['assets.other'] ? parseFloat(data['assets.other']) : undefined
            },
            declarations: {
                confirm_reviewed: document.getElementsByName('declarations.confirm_reviewed')[0]?.checked || false,
                confirm_complex_advice: document.getElementsByName('declarations.confirm_complex_advice')[0]?.checked || false,
                confirm_super_and_joint: document.getElementsByName('declarations.confirm_super_and_joint')[0]?.checked || false,
                confirm_signing_witness: document.getElementsByName('declarations.confirm_signing_witness')[0]?.checked || false,
                intended_signing_date: data['declarations.intended_signing_date'] || undefined
            }
        };
    }

    // API Calls
    async function generateWill() {
        showLoading();
        clearErrors();

        const payload = buildPayload();

        try {
            // First validate
            const validateResponse = await fetch(`${CONFIG.API_BASE}/validate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const validateResult = await validateResponse.json();

            if (!validateResult.ok) {
                hideLoading();
                showErrors(validateResult.errors);
                return;
            }

            // Then generate
            const generateResponse = await fetch(`${CONFIG.API_BASE}/generate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!generateResponse.ok) {
                const error = await generateResponse.json();
                hideLoading();
                showErrors(error.errors || [{ field: '', message: 'Failed to generate will' }]);
                return;
            }

            // Get PDF blob
            const pdfBlob = await generateResponse.blob();
            const pdfUrl = URL.createObjectURL(pdfBlob);

            // Store for modal download
            window.generatedPdfUrl = pdfUrl;

            hideLoading();
            showSuccessModal();

            // Auto-download
            const a = document.createElement('a');
            a.href = pdfUrl;
            a.download = 'Last_Will_and_Testament.pdf';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);

        } catch (error) {
            hideLoading();
            showErrors([{ field: '', message: 'Network error. Please try again.' }]);
            console.error('Generation error:', error);
        }
    }

    // UI Helpers
    function showLoading() {
        loadingOverlay.classList.remove('hidden');
    }

    function hideLoading() {
        loadingOverlay.classList.add('hidden');
    }

    function showErrors(errors) {
        errorList.innerHTML = '';
        
        errors.forEach(error => {
            const li = document.createElement('li');
            const link = document.createElement('a');
            link.href = error.field ? `#${error.field.split('.')[0]}` : '#';
            link.textContent = `${error.field || 'General'}: ${error.message}`;
            link.addEventListener('click', (e) => {
                e.preventDefault();
                scrollToField(error.field);
            });
            li.appendChild(link);
            errorList.appendChild(li);

            // Highlight field
            if (error.field) {
                const field = document.getElementsByName(error.field)[0];
                if (field) {
                    field.classList.add('error');
                    const errorSpan = document.querySelector(`[data-field="${error.field}"]`);
                    if (errorSpan) {
                        errorSpan.textContent = error.message;
                    }
                }
            }
        });

        errorSummary.classList.remove('hidden');
        errorSummary.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function clearErrors() {
        errorSummary.classList.add('hidden');
        errorList.innerHTML = '';
        document.querySelectorAll('.error').forEach(el => el.classList.remove('error'));
        document.querySelectorAll('.field-error').forEach(el => el.textContent = '');
    }

    function scrollToField(fieldName) {
        if (!fieldName) return;
        const field = document.getElementsByName(fieldName)[0];
        if (field) {
            field.scrollIntoView({ behavior: 'smooth', block: 'center' });
            field.focus();
        }
    }

    function showSuccessModal() {
        successModal.classList.remove('hidden');
    }

    function closeModal() {
        successModal.classList.add('hidden');
    }

    function updateSummary() {
        const summaryContent = document.getElementById('summary-content');
        if (!summaryContent) return;

        const payload = buildPayload();
        const parts = [];

        if (payload.will_maker.full_name) {
            parts.push(`<p><strong>Will Maker:</strong> ${payload.will_maker.full_name}</p>`);
        }

        if (payload.has_children && payload.children.length > 0) {
            parts.push(`<p><strong>Children:</strong> ${payload.children.length}</p>`);
        }

        if (payload.executors.mode) {
            const modeLabels = {
                'partner_only': 'Partner only',
                'one': 'One executor',
                'two_joint': 'Two executors (jointly)',
                'two_joint_and_several': 'Two executors (jointly and severally)'
            };
            parts.push(`<p><strong>Executors:</strong> ${modeLabels[payload.executors.mode] || payload.executors.mode}</p>`);
        }

        if (payload.beneficiaries.length > 0) {
            parts.push(`<p><strong>Beneficiaries:</strong> ${payload.beneficiaries.length}</p>`);
        }

        if (parts.length === 0) {
            summaryContent.innerHTML = '<p class="summary-placeholder">Complete the form to see a summary of your will.</p>';
        } else {
            summaryContent.innerHTML = parts.join('');
        }
    }

    // Navigation
    function setupNavigation() {
        // Highlight current section on scroll
        const sections = document.querySelectorAll('.form-section');
        const navItems = document.querySelectorAll('.nav-item');

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const section = entry.target.dataset.section;
                    navItems.forEach(item => {
                        item.classList.toggle('active', item.dataset.section === section);
                    });
                }
            });
        }, { rootMargin: '-20% 0px -80% 0px' });

        sections.forEach(section => observer.observe(section));

        // Smooth scroll for nav links
        navItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(item.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
                // Close mobile nav
                if (navList) {
                    navList.classList.remove('open');
                    navToggle.setAttribute('aria-expanded', 'false');
                }
            });
        });
    }

    function toggleNavigation() {
        const expanded = navToggle.getAttribute('aria-expanded') === 'true';
        navToggle.setAttribute('aria-expanded', !expanded);
        navList.classList.toggle('open');
    }

})();
